const fname = document.getElementById('firstname');
const lname = document.getElementById('lastname');
const dob = document.getElementById('dob');

const errorElement = document.getElementById('error');
const gender = document.getElementById('gender');
const email = document.getElementById('email');
const phone = document.getElementById('phonenumber');
const address1 = document.getElementById('address');
const address2 = document.getElementById('address2');
const password = document.getElementById('password');
const question = document.getElementById('question');

const form = document.getElementById('form');

form.addEventListener('submit',(e) =>{
    let messages = [];
     if(fname.value === '' || fname.value === null){
        alert('First Name required!');
     }

     if(fname.value.length < 3){
         alert('First Name is too short');
     }

     if(fname.value.length > 30){
         alert('First Name is too long. cannot be more than 30 characters');
     }

     var regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
     if(!regName.test(fname.value)){
         alert('Invalid name');
     }

     var regEmail = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if(!regEmail.test(email.value)){
         alert("Invalid Email");
     }

     var regPhone = /^(\+91-|\+91|0)?\d{10}$/;

     if(!regPhone.test(phone.value)){
         alert('Invalid Phone');
     }



     if(lname.value === '' || lname.value === null){
         alert('Last Name required');
     }

     if(dob.value === '' || dob.value ===null){
         messages.push('Date of Birth is required')
     }

    if(gender.value === '' || gender.value === null){
         messages.push('Gender is required');
     }

     if(email.value === '' || email.value === null){
         messages.push('Email required');
     }

     if(phone.value === '' || phone.value === null){
         messages.push('Phone required');
     }

     if(address.value === '' || address.value === null){
         messages.push('Address Required');
     }

     if(password.value === '' || password.value === null){
         alert('password cannot be empty');
     }

     if(password.value.length< 12){
         alert('password too short must be minimum of 12 characters!');
     }

    var regPassword = /^[a-zA-Z0-9!@#$%^&*]{6,12}$/;
    if(!regPassword.test(password.value)){
        alert('Must contain 1 uppercase , 1 lowercase and a special character.');
    }

     if(question.value === '' || question.value === null){
         messages.push('Please type your question');
     }



    if(messages.length > 0 ){
        e.preventDefault();
        errorElement.innerText = messages.join(',   ');
    }
});

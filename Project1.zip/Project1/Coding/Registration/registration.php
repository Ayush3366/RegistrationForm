<!-- Main Page -->
<?php
require_once('config.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Contact Form</title>
    <link rel = "stylesheet" type = "text/css" href="css/bootstrap.min.css">
	<script defer src="script.js"></script>
</head>
<body style="background-color:beige;">
<div id = "error"></div>
    
    <div>
        <?php
        if(isset($_POST['create'])){
            $firstname = $_POST['firstname'];
            $lastname = $_POST['lastname'];
			$gender = $_POST['gender'];
            $email = $_POST['email'];
            $phonenumber = $_POST['phonenumber'];
			$address1 = $_POST['address1'];
			$address2 = $_POST['address2'];
			$province = $_POST['province'];
            $password = $_POST['password'];
			$news = $_POST['news'];
			$question = $_POST['question'];

			$sql = "INSERT INTO users (firstname,lastname,gender,email,phonenumber,address1,address2,province,password,news,question) values (?,?,?,?,?,?,?,?,?,?,?) ";
			$stmtinsert = $db->prepare($sql);
			$result = $stmtinsert->execute([$firstname,$lastname,$gender,$email,$phonenumber,$address1,$address2,$province,$password,$news,$question]);

			if($result){
				echo 'Successful saved.';

			}else {
				echo 'There were errors while saving the data';
			}
        }
        ?>
    </div>

    <div>
	<form action="registration.php" method="post" id="form">
		<div class="container">
			
			<div class="row">
				<div class="col-sm-3">
					
					<h1>Contact</h1>
					<p>Fill up the form with correct values.</p>
					<hr class="mb-3">
					<label for="firstname"><b>First Name</b></label>
					<input class="form-control" id="firstname" type="text" name="firstname" >

					<label for="lastname"><b>Last Name</b></label>
					<input class="form-control" id="lastname"  type="text" name="lastname" >

					<label for="Gender"><b>Gender</b></label><br>
					<label for = "Gender">Male</label>
					<input id="gender" type="radio" name="gender" >
					<label for = "Gender">Female</label>
					<input id="gender" type="radio" name="gender" ><br>


					<label for="email"><b>Email Address</b></label>
					<input class="form-control" id="email"  type="email" name="email" >

					<label for="phonenumber"><b>Phone Number</b></label>
					<input class="form-control" id="phonenumber"  type="text" name="phonenumber" >

					<label for="Address"><b>Address</b></label>
					<input class="form-control" id="address"  type="text" name="address1"  placeholder="Address"><br>
					<input class="form-control" id="address"  type="text" name="address2"  placeholder="House Number"><br>
					<select name="province" id="address3">
					<option value="ON">ON</option>
					<option value="AB">AB</option>
					<option value="MB">MB</option>
					<option value="NB">NB</option>
					<option value="NF">NF</option>
					<option value="NS">NS</option>
					<option value="NV">NV</option>
					<option value="PEI">PEI</option>
					<option value="QUB">QUB</option>
					<option value="SKW">SKW</option>
					<option value="YUK">YUK</option>
					</select>
					<br><br>


					<label for="password"><b>Password</b></label>
					<input class="form-control" id="password"  type="password" name="password" ><br>

					<input id="news"  type="checkbox" name="news">
					<label for="news"><b>Send Me monthly Newsletter</b></label><br>

					<label for="question"><b>What is your Question</b></label>
					<textarea id = "question" name="question" rows="4" cols="50"></textarea>


					<hr class="mb-3">
					<input class="btn btn-primary" type="submit" id="register" name="create" value="Sign Up">
				</div>
			</div>
		</div>
	</form>
</div>
</body>
</html>